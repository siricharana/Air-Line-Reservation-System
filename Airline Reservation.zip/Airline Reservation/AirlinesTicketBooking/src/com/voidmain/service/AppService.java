package com.voidmain.service;

import com.voidmain.dao.HibernateDAO;
import com.voidmain.pojo.Ticket;

public class AppService {

	public static int getAvaliableTickets(String dateOfJourney,String seatclass, String filightid)
	{
		int count=0;
		
		for(Ticket ticket : HibernateDAO.getTickets())
		{
			if(ticket.getFlightid().equals(filightid) && ticket.getSeatclass().equals(seatclass) && ticket.getDateofjourney().equals(dateOfJourney))
			{
				count=count+1;
			}
		}
		
		return count;
	}
}
