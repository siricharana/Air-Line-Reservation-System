package com.voidmain.dao;

import java.util.List;

import com.voidmain.pojo.Fare;
import com.voidmain.pojo.Flight;
import com.voidmain.pojo.Login;
import com.voidmain.pojo.Ticket;
import com.voidmain.pojo.User;

public class HibernateDAO {

	public static String isValidUser(String username,String password)
	{
		String result="0";

		Login login=getLoginById(username);

		if(login!=null && login.getPassword().equals(password) && login.getStatus().equals("yes"))
		{
			result=login.getRole();
		}

		return result;
	}

	public static boolean isUserRegistred(String username)
	{
		boolean isRegistred=false;

		for(Login login : getLogins())
		{
			if(login.getUsername().toLowerCase().equals(username.toLowerCase()))
			{
				isRegistred=true;

				break;
			}
		}

		return isRegistred;
	}

	//================================================================================

	public static Login getLoginById(String username)
	{
		return (Login)HibernateTemplate.getObject(Login.class,username);
	}

	public static int deleteLogin(String username)
	{
		return HibernateTemplate.deleteObject(Login.class,username);
	}

	public static List<Login> getLogins()
	{
		List<Login> logins=(List)HibernateTemplate.getObjectListByQuery("From Login");

		return logins;
	}

	//============================================================================

	public static User getUserById(String id)
	{
		return (User)HibernateTemplate.getObject(User.class,id);
	}

	public static int deleteUser(int id)
	{
		return HibernateTemplate.deleteObject(User.class,id);
	}

	public static List<User> getUsers()
	{
		List<User> users=(List)HibernateTemplate.getObjectListByQuery("From User");

		return users;
	}

	//=========================================================================

	public static Flight getFlightById(String id)
	{
		return (Flight)HibernateTemplate.getObject(Flight.class,id);
	}

	public static int deleteFlight(int id)
	{
		return HibernateTemplate.deleteObject(Flight.class,id);
	}

	public static List<Flight> getFlights()
	{
		List<Flight> flights=(List)HibernateTemplate.getObjectListByQuery("From Flight");

		return flights;
	}

	//================================================================================

	public static Fare getFareById(int id)
	{
		return (Fare)HibernateTemplate.getObject(Fare.class,id);
	}

	public static int deleteFare(int id)
	{
		return HibernateTemplate.deleteObject(Fare.class,id);
	}

	public static List<Fare> getFares()
	{
		List<Fare> fares=(List)HibernateTemplate.getObjectListByQuery("From Fare");

		return fares;
	}

	//================================================================================

	public static Ticket getTicketById(int id)
	{
		return (Ticket)HibernateTemplate.getObject(Ticket.class,id);
	}

	public static int deleteTicket(int id)
	{
		return HibernateTemplate.deleteObject(Ticket.class,id);
	}

	public static List<Ticket> getTickets()
	{
		List<Ticket> tickets=(List)HibernateTemplate.getObjectListByQuery("From Ticket");

		return tickets;
	}
}
