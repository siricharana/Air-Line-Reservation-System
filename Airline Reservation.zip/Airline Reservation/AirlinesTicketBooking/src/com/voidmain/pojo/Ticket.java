package com.voidmain.pojo;

public class Ticket {

	private int id;
	private String seatclass;
	private String dateofjourney;
	private String userid;
	private String flightid;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSeatclass() {
		return seatclass;
	}
	public void setSeatclass(String seatclass) {
		this.seatclass = seatclass;
	}
	public String getDateofjourney() {
		return dateofjourney;
	}
	public void setDateofjourney(String dateofjourney) {
		this.dateofjourney = dateofjourney;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getFlightid() {
		return flightid;
	}
	public void setFlightid(String flightid) {
		this.flightid = flightid;
	}
}
